# https://github.com/sebastian-lenz/typedoc

rm docs/vsotask.json
typedoc --module commonjs --json docs/vsotask.json lib